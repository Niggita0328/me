#pragma once  
  
#include "geo.h"  
  
#include <string>  
#include <vector>  
#include <set>  
#include <unordered_map>  
#include <unordered_set> 
 
namespace transport { 
 
struct Stop { 
    std::string name; 
    geo::Coordinates coordinates; 
    std::unordered_set<std::string> buses_by_stop;
    std::unordered_map<std::string, int> distances;
}; 
 
struct Bus { 
    std::string number;                     
    std::vector<const Stop*> stops;         
    bool is_circular;                         
}; 
 
struct BusStat { 
    size_t stops_count;                     
    size_t unique_stops_count;             
    double route_length;             
    double curvature;                        
};

struct RoutingSettings {
    int bus_wait_time;
    double bus_velocity;
};
 
}  // namespace transport