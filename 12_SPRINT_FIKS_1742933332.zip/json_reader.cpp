#include "json_reader.h" 
#include "json_builder.h" 
#include "transport_catalogue.h" 
#include "map_renderer.h" 

const json::Node& JsonReader::GetBaseRequests() const { 
    auto it = input_.GetRoot().AsDict().find("base_requests"); 
    return it != input_.GetRoot().AsDict().end() ? it->second : dummy_; 
} 

const json::Node& JsonReader::GetStatRequests() const { 
    auto it = input_.GetRoot().AsDict().find("stat_requests"); 
    return it != input_.GetRoot().AsDict().end() ? it->second : dummy_; 
} 

const json::Node& JsonReader::GetRenderSettings() const { 
    auto it = input_.GetRoot().AsDict().find("render_settings"); 
    return it != input_.GetRoot().AsDict().end() ? it->second : dummy_; 
} 

void JsonReader::ProcessRequests(const json::Node& stat_requests, RequestHandler& rh) const {
    json::Array result;
    for (const auto& request : stat_requests.AsArray()) {
        const auto& request_map = request.AsDict();
        const auto& type = request_map.at("type").AsString();

        if (type == "Stop") {
            result.push_back(PrintStop(request_map, rh));
        } else if (type == "Bus") {
            result.push_back(PrintBusRoute(request_map, rh));
        } else if (type == "Map") {
            result.push_back(PrintMap(request_map, rh));
        } else if (type == "Route") {
            result.push_back(PrintRouteInfo(request_map, rh));
        }
    }
    json::Print(json::Document{result}, std::cout);
}

void JsonReader::FillCatalogue(transport::Catalogue& catalogue) { 
    ProcessStops(catalogue); 
    FillStopDistances(catalogue); 
    ProcessBuses(catalogue); 
} 

void JsonReader::ProcessStops(transport::Catalogue& catalogue) { 
    for (const auto& request : GetBaseRequests().AsArray()) { 
        const auto& request_map = request.AsDict(); 
        if (request_map.at("type").AsString() == "Stop") { 
            catalogue.AddStop(CreateStop(request_map)); 
        } 
    } 
} 

void JsonReader::ProcessBuses(transport::Catalogue& catalogue) { 
    for (const auto& request : GetBaseRequests().AsArray()) { 
        const auto& request_map = request.AsDict(); 
        if (request_map.at("type").AsString() == "Bus") { 
            catalogue.AddRoute(CreateBus(request_map, catalogue)); 
        } 
    } 
} 

transport::Stop JsonReader::CreateStop(const json::Dict& request_map) const { 
    transport::Stop stop; 
    stop.name = request_map.at("name").AsString(); 
    stop.coordinates = { request_map.at("latitude").AsDouble(), request_map.at("longitude").AsDouble() }; 
    
    for (const auto& [stop_name, dist] : request_map.at("road_distances").AsDict()) { 
        stop.distances[stop_name] = dist.AsInt(); 
    } 
    return stop; 
} 

void JsonReader::FillStopDistances(transport::Catalogue& catalogue) const { 
    for (const auto& request : GetBaseRequests().AsArray()) { 
        const auto& request_map = request.AsDict(); 
        if (request_map.at("type").AsString() == "Stop") { 
            transport::Stop stop = CreateStop(request_map); 
            for (const auto& [to_name, dist] : stop.distances) { 
                catalogue.SetDistance(catalogue.FindStop(stop.name), catalogue.FindStop(to_name), dist); 
            } 
        } 
    } 
} 

transport::Bus JsonReader::CreateBus(const json::Dict& request_map, transport::Catalogue& catalogue) const { 
    transport::Bus bus; 
    bus.number = request_map.at("name").AsString(); 
    bus.is_circular = request_map.at("is_roundtrip").AsBool(); 
    for (const auto& stop : request_map.at("stops").AsArray()) { 
        bus.stops.push_back(catalogue.FindStop(stop.AsString())); 
    } 
    return bus; 
} 

renderer::MapRenderer JsonReader::FillRenderSettings(const json::Dict& request_map) const {
    renderer::RenderSettings render_settings;
    render_settings.width = request_map.at("width").AsDouble();
    render_settings.height = request_map.at("height").AsDouble();
    render_settings.padding = request_map.at("padding").AsDouble();
    render_settings.stop_radius = request_map.at("stop_radius").AsDouble();
    render_settings.line_width = request_map.at("line_width").AsDouble();
    render_settings.bus_label_font_size = request_map.at("bus_label_font_size").AsInt();
    const json::Array& bus_label_offset = request_map.at("bus_label_offset").AsArray();
    render_settings.bus_label_offset = { bus_label_offset[0].AsDouble(), bus_label_offset[1].AsDouble() };
    render_settings.stop_label_font_size = request_map.at("stop_label_font_size").AsInt();
    const json::Array& stop_label_offset = request_map.at("stop_label_offset").AsArray();
    render_settings.stop_label_offset = { stop_label_offset[0].AsDouble(), stop_label_offset[1].AsDouble() };
    
    if (request_map.at("underlayer_color").IsString()) render_settings.underlayer_color = request_map.at("underlayer_color").AsString();
    else if (request_map.at("underlayer_color").IsArray()) {
        const json::Array& underlayer_color = request_map.at("underlayer_color").AsArray();
        if (underlayer_color.size() == 3) {
            render_settings.underlayer_color = svg::Rgb(underlayer_color[0].AsInt(), underlayer_color[1].AsInt(), underlayer_color[2].AsInt());
        }
        else if (underlayer_color.size() == 4) {
            render_settings.underlayer_color = svg::Rgba(underlayer_color[0].AsInt(), underlayer_color[1].AsInt(), underlayer_color[2].AsInt(), underlayer_color[3].AsDouble());
        } else throw std::logic_error("wrong underlayer colortype");
    } else throw std::logic_error("wrong underlayer color");
    
    render_settings.underlayer_width = request_map.at("underlayer_width").AsDouble();
    
    const json::Array& color_palette = request_map.at("color_palette").AsArray();
    for (const auto& color_element : color_palette) {
        if (color_element.IsString()) render_settings.color_palette.push_back(color_element.AsString());
        else if (color_element.IsArray()) {
            const json::Array& color_type = color_element.AsArray();
            if (color_type.size() == 3) {
                render_settings.color_palette.push_back(svg::Rgb(color_type[0].AsInt(), color_type[1].AsInt(), color_type[2].AsInt()));
            }
            else if (color_type.size() == 4) {
                render_settings.color_palette.push_back(svg::Rgba(color_type[0].AsInt(), color_type[1].AsInt(), color_type[2].AsInt(), color_type[3].AsDouble()));
            } else throw std::logic_error("wrong color_palette type");
        } else throw std::logic_error("wrong color_palette");
    }
    
    return render_settings;
}

const json::Node JsonReader::PrintBusRoute(const json::Dict& request_map, RequestHandler& rh) const {
    const std::string& route_number = request_map.at("name").AsString();
    const int id = request_map.at("id").AsInt();
    
    if (!rh.IsBusNumber(route_number)) {
        return json::Builder{} 
                .StartDict() 
                    .Key("request_id").Value(id) 
                    .Key("error_message").Value("not found") 
                .EndDict() 
            .Build(); 
    }
    const auto& route_info = rh.GetBusStat(route_number);
    return json::Builder{} 
            .StartDict() 
                .Key("request_id").Value(id) 
                .Key("curvature").Value(route_info->curvature) 
                .Key("route_length").Value(route_info->route_length)
                .Key("stop_count").Value(static_cast<int>(route_info->stops_count)) 
                .Key("unique_stop_count").Value(static_cast<int>(route_info->unique_stops_count)) 
            .EndDict() 
        .Build(); 
}

const json::Node JsonReader::PrintStop(const json::Dict& request_map, RequestHandler& rh) const {
    const std::string& stop_name = request_map.at("name").AsString();
    const int id = request_map.at("id").AsInt();
    
    if (!rh.IsStopName(stop_name)) {
        return json::Builder{}
                .StartDict()
                    .Key("request_id").Value(id)
                    .Key("error_message").Value("not found")
                .EndDict()
            .Build();
    }

    std::vector<std::string> sorted_buses(rh.GetBusesByStop(stop_name).begin(), rh.GetBusesByStop(stop_name).end());
    std::sort(sorted_buses.begin(), sorted_buses.end());
    
    json::Array buses;
    for (const auto& bus : sorted_buses) {
        buses.push_back(bus);
    }
    
    return json::Builder{}
            .StartDict()
                .Key("request_id").Value(id)
                .Key("buses").Value(buses)
            .EndDict()
        .Build();
}

const json::Node JsonReader::PrintMap(const json::Dict& request_map, RequestHandler& rh) const { 
    const int id = request_map.at("id").AsInt(); 
    std::ostringstream strm; 
    svg::Document map = rh.RenderMap(); 
    map.Render(strm); 
    
    return json::Builder{} 
            .StartDict() 
                .Key("request_id").Value(id) 
                .Key("map").Value(strm.str()) 
            .EndDict() 
        .Build(); 
}

const json::Node& JsonReader::GetRoutingSettings() const {
    auto it = input_.GetRoot().AsDict().find("routing_settings");
    return it != input_.GetRoot().AsDict().end() ? it->second : dummy_;
}

transport::RoutingSettings JsonReader::FillRoutingSettings(const json::Dict& request_map) const {
    transport::RoutingSettings routing_settings;
    routing_settings.bus_wait_time = request_map.at("bus_wait_time").AsInt();
    routing_settings.bus_velocity = request_map.at("bus_velocity").AsDouble();
    return routing_settings;
}

const json::Node JsonReader::PrintRouteInfo(const json::Dict& request_map, RequestHandler& rh) const {
    const std::string& from = request_map.at("from").AsString();
    const std::string& to = request_map.at("to").AsString();
    const int id = request_map.at("id").AsInt();
    
    auto route_info = rh.BuildRoute(from, to);
    
    if (!route_info) {
        return json::Builder{}
                .StartDict()
                    .Key("request_id").Value(id)
                    .Key("error_message").Value("not found")
                .EndDict()
            .Build();
    }
    
    json::Array items;
    for (const auto& item : route_info->items) {
        if (std::holds_alternative<transport::TransportRouter::WaitItem>(item)) {
            const auto& wait_item = std::get<transport::TransportRouter::WaitItem>(item);
            items.push_back(
                json::Builder{}
                    .StartDict()
                        .Key("type").Value("Wait")
                        .Key("stop_name").Value(wait_item.stop_name)
                        .Key("time").Value(wait_item.time)
                    .EndDict()
                .Build().AsDict()
            );
        } else {
            const auto& bus_item = std::get<transport::TransportRouter::BusItem>(item);
            items.push_back(
                json::Builder{}
                    .StartDict()
                        .Key("type").Value("Bus")
                        .Key("bus").Value(bus_item.bus)
                        .Key("span_count").Value(bus_item.span_count)
                        .Key("time").Value(bus_item.time)
                    .EndDict()
                .Build().AsDict()
            );
        }
    }
    
    return json::Builder{}
            .StartDict()
                .Key("request_id").Value(id)
                .Key("total_time").Value(route_info->total_time)
                .Key("items").Value(items)
            .EndDict()
        .Build();
}