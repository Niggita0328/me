#pragma once  
  
#include "json.h"  
#include "transport_catalogue.h"  
#include "map_renderer.h"  
#include "request_handler.h"  
  
#include <iostream>  
  
class JsonReader {  
public:  
    JsonReader(std::istream& input)  
        : input_(json::Load(input))  
    {}  
  
    const json::Node& GetBaseRequests() const;  
    const json::Node& GetStatRequests() const;  
    const json::Node& GetRenderSettings() const;  
    const json::Node& GetRoutingSettings() const;  // Новый метод
  
    void ProcessRequests(const json::Node& stat_requests, RequestHandler& rh) const;  
  
    void FillCatalogue(transport::Catalogue& catalogue);  
    renderer::MapRenderer FillRenderSettings(const json::Dict& request_map) const;  
    transport::RoutingSettings FillRoutingSettings(const json::Dict& request_map) const; // Новый метод
  
    const json::Node PrintBusRoute(const json::Dict& request_map, RequestHandler& rh) const;  
    const json::Node PrintStop(const json::Dict& request_map, RequestHandler& rh) const;  
    const json::Node PrintMap(const json::Dict& request_map, RequestHandler& rh) const;  
    const json::Node PrintRouteInfo(const json::Dict& request_map, RequestHandler& rh) const;  // Новое имя для метода
    
    void ProcessStops(transport::Catalogue& catalogue);
    void ProcessBuses(transport::Catalogue& catalogue);
    transport::Stop CreateStop(const json::Dict& request_map) const;
    transport::Bus CreateBus(const json::Dict& request_map, transport::Catalogue& catalogue) const;
    void FillStopDistances(transport::Catalogue& catalogue) const;
  
private:  
    json::Document input_;  
    json::Node dummy_ = nullptr;  
};