#include "json_reader.h"
#include "request_handler.h"
#include "transport_router.h"

int main() {
    transport::Catalogue catalogue;
    JsonReader json_doc(std::cin);
    
    json_doc.FillCatalogue(catalogue);
    
    const auto& stat_requests = json_doc.GetStatRequests();
    const auto& render_settings = json_doc.GetRenderSettings().AsDict();
    const auto& routing_settings_node = json_doc.GetRoutingSettings();
    const auto& routing_settings = json_doc.FillRoutingSettings(routing_settings_node.AsDict());
    
    const auto renderer = json_doc.FillRenderSettings(render_settings);
    
    transport::TransportRouter router(catalogue, routing_settings);
    
    RequestHandler rh(catalogue, renderer, router);
    json_doc.ProcessRequests(stat_requests, rh);
}