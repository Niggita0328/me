#include "map_renderer.h"  
  
namespace renderer {  
  
bool IsZero(double value) {  
    return std::abs(value) < EPSILON;  
}  
 
void MapRenderer::RenderRouteLines(svg::Document& result, const std::map<std::string_view, const transport::Bus*>& buses, const SphereProjector& sp) const { 
    size_t color_num = 0; 
    for (const auto& [bus_number, bus] : buses) { 
        if (bus->stops.empty()) continue; 
        std::vector<const transport::Stop*> route_stops{ bus->stops.begin(), bus->stops.end() }; 
        if (!bus->is_circular) route_stops.insert(route_stops.end(), std::next(bus->stops.rbegin()), bus->stops.rend()); 
         
        svg::Polyline line; 
        for (const auto& stop : route_stops) { 
            line.AddPoint(sp(stop->coordinates)); 
        } 
        line.SetStrokeColor(render_settings_.color_palette[color_num]); 
        line.SetFillColor("none"); 
        line.SetStrokeWidth(render_settings_.line_width); 
        line.SetStrokeLineCap(svg::StrokeLineCap::ROUND); 
        line.SetStrokeLineJoin(svg::StrokeLineJoin::ROUND); 
         
        color_num = (color_num + 1) % render_settings_.color_palette.size(); 
        result.Add(line); 
    } 
} 
 
void MapRenderer::RenderBusLabels(svg::Document& result, const std::map<std::string_view, const transport::Bus*>& buses, const SphereProjector& sp) const { 
    size_t color_num = 0; 
    for (const auto& [bus_number, bus] : buses) { 
        if (bus->stops.empty()) continue; 
 
        svg::Text text, underlayer; 
        text.SetPosition(sp(bus->stops[0]->coordinates)); 
        text.SetOffset(render_settings_.bus_label_offset); 
        text.SetFontSize(render_settings_.bus_label_font_size); 
        text.SetFontFamily("Verdana"); 
        text.SetFontWeight("bold"); 
        text.SetData(bus->number); 
        text.SetFillColor(render_settings_.color_palette[color_num]); 
 
        underlayer = text; 
        underlayer.SetFillColor(render_settings_.underlayer_color); 
        underlayer.SetStrokeColor(render_settings_.underlayer_color); 
        underlayer.SetStrokeWidth(render_settings_.underlayer_width); 
        underlayer.SetStrokeLineCap(svg::StrokeLineCap::ROUND); 
        underlayer.SetStrokeLineJoin(svg::StrokeLineJoin::ROUND); 
 
        result.Add(underlayer); 
        result.Add(text); 
 
        if (!bus->is_circular && bus->stops[0] != bus->stops.back()) { 
            svg::Text text2 = text; 
            svg::Text underlayer2 = underlayer; 
            text2.SetPosition(sp(bus->stops.back()->coordinates)); 
            underlayer2.SetPosition(sp(bus->stops.back()->coordinates)); 
            result.Add(underlayer2); 
            result.Add(text2); 
        } 
 
        color_num = (color_num + 1) % render_settings_.color_palette.size(); 
    } 
} 
 
void MapRenderer::RenderStopSymbols(svg::Document& result, const std::map<std::string_view, const transport::Stop*>& stops, const SphereProjector& sp) const { 
    for (const auto& [stop_name, stop] : stops) { 
        svg::Circle symbol; 
        symbol.SetCenter(sp(stop->coordinates)); 
        symbol.SetRadius(render_settings_.stop_radius); 
        symbol.SetFillColor("white"); 
        result.Add(symbol); 
    } 
} 
 
void MapRenderer::RenderStopLabels(svg::Document& result, const std::map<std::string_view, const transport::Stop*>& stops, const SphereProjector& sp) const { 
    for (const auto& [stop_name, stop] : stops) { 
        svg::Text text, underlayer; 
        text.SetPosition(sp(stop->coordinates)); 
        text.SetOffset(render_settings_.stop_label_offset); 
        text.SetFontSize(render_settings_.stop_label_font_size); 
        text.SetFontFamily("Verdana"); 
        text.SetData(stop->name); 
        text.SetFillColor("black"); 
 
        underlayer = text; 
        underlayer.SetFillColor(render_settings_.underlayer_color); 
        underlayer.SetStrokeColor(render_settings_.underlayer_color); 
        underlayer.SetStrokeWidth(render_settings_.underlayer_width); 
        underlayer.SetStrokeLineCap(svg::StrokeLineCap::ROUND); 
        underlayer.SetStrokeLineJoin(svg::StrokeLineJoin::ROUND); 
 
        result.Add(underlayer); 
        result.Add(text); 
    } 
} 
 
void MapRenderer::AddElementsToSVG(svg::Document& result, const std::map<std::string_view, const transport::Bus*>& buses, const SphereProjector& sp, const std::map<std::string_view, const transport::Stop*>& stops) const { 
    RenderRouteLines(result, buses, sp); 
    RenderBusLabels(result, buses, sp); 
    RenderStopSymbols(result, stops, sp); 
    RenderStopLabels(result, stops, sp); 
} 
 
svg::Document MapRenderer::GetSVG(const std::map<std::string_view, const transport::Bus*>& buses) const { 
    svg::Document result; 
    std::vector<geo::Coordinates> route_stops_coord; 
    std::map<std::string_view, const transport::Stop*> all_stops; 
 
    for (const auto& [bus_number, bus] : buses) { 
        if (bus->stops.empty()) continue; 
        for (const auto& stop : bus->stops) { 
            route_stops_coord.push_back(stop->coordinates); 
            all_stops[stop->name] = stop; 
        } 
    } 
 
    SphereProjector sp(route_stops_coord.begin(), route_stops_coord.end(), render_settings_.width, render_settings_.height, render_settings_.padding); 
    AddElementsToSVG(result, buses, sp, all_stops); 
 
    return result; 
} 
 
}