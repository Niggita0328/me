#include "request_handler.h"  
  
std::optional<transport::BusStat> RequestHandler::GetBusStat(const std::string_view bus_number) const {  
    return catalogue_.GetBusStat(bus_number);  
}  
  
const std::unordered_set<std::string>& RequestHandler::GetBusesByStop(std::string_view stop_name) const {  
    return catalogue_.GetBusesByStop(stop_name);  
}
  
bool RequestHandler::IsBusNumber(const std::string_view bus_number) const {  
    return catalogue_.FindRoute(bus_number);  
}  
  
bool RequestHandler::IsStopName(const std::string_view stop_name) const {  
    return catalogue_.FindStop(stop_name);  
}  
  
svg::Document RequestHandler::RenderMap() const {  
    std::map<std::string_view, const transport::Bus*> buses_map;
    for (const auto& bus : catalogue_.GetAllBuses()) {
        buses_map[bus.number] = &bus;
    }
    return renderer_.GetSVG(buses_map);
}

std::optional<transport::TransportRouter::RouteInfo> RequestHandler::BuildRoute(
    std::string_view from, std::string_view to) const {
    return router_.BuildRoute(from, to);
}