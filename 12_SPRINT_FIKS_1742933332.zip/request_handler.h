#pragma once   
   
#include "json.h"   
#include "transport_catalogue.h"   
#include "map_renderer.h"   
#include "transport_router.h"
   
#include <sstream>   
   
class RequestHandler {   
public:   
    RequestHandler(const transport::Catalogue& catalogue, 
                  const renderer::MapRenderer& renderer,
                  const transport::TransportRouter& router)   
        : catalogue_(catalogue)   
        , renderer_(renderer)   
        , router_(router)
    {   
    }   
   
    std::optional<transport::BusStat> GetBusStat(const std::string_view bus_number) const;   
    const std::unordered_set<std::string>& GetBusesByStop(std::string_view stop_name) const;  
   
    bool IsBusNumber(const std::string_view bus_number) const;   
    bool IsStopName(const std::string_view stop_name) const;   
   
    svg::Document RenderMap() const;   
    
    std::optional<transport::TransportRouter::RouteInfo> BuildRoute(
        std::string_view from, std::string_view to) const;
   
private:   
    const transport::Catalogue& catalogue_;   
    const renderer::MapRenderer& renderer_;   
    const transport::TransportRouter& router_;
};