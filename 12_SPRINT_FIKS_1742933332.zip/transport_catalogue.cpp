#include "transport_catalogue.h"   
   
namespace transport {   

void Catalogue::AddStop(const Stop& stop) {
    all_stops_.push_back(stop);
    stopname_to_stop_[all_stops_.back().name] = &all_stops_.back();
} 

void Catalogue::AddRoute(const Bus& bus) {
    all_buses_.push_back(bus);
    busname_to_bus_[all_buses_.back().number] = &all_buses_.back();

    for (const auto& stop : bus.stops) {   
        auto stop_iter = stopname_to_stop_.find(stop->name);  
        if (stop_iter != stopname_to_stop_.end()) {  
            stop_iter->second->buses_by_stop.insert(std::string(bus.number));  
        }  
    }
}
   
const Bus* Catalogue::FindRoute(std::string_view bus_number) const {   
    auto bus_iter = busname_to_bus_.find(bus_number);  
    return bus_iter != busname_to_bus_.end() ? bus_iter->second : nullptr;  
}   
   
const Stop* Catalogue::FindStop(std::string_view stop_name) const {   
    auto stop_iter = stopname_to_stop_.find(stop_name);  
    return stop_iter != stopname_to_stop_.end() ? stop_iter->second : nullptr;  
}   
   
std::optional<transport::BusStat> Catalogue::GetBusStat(std::string_view bus_number) const {   
    BusStat bus_stat{};   
    const Bus* bus = FindRoute(bus_number);   
       
    if (!bus) return std::nullopt;   
   
    bus_stat.stops_count = bus->stops.size();   
    if (!bus->is_circular) {   
        bus_stat.stops_count = bus->stops.size() * 2 - 1;   
    }   
   
    double route_length = 0.0;   
    double geo_length = 0.0;   
   
    for (size_t i = 0; i < bus->stops.size() - 1; ++i) {   
        auto from = bus->stops[i];   
        auto to = bus->stops[i + 1];   
        
        if (bus->is_circular) {
            route_length += GetDistance(from, to);   
            geo_length += geo::ComputeDistance(from->coordinates, to->coordinates);
        } else {
            route_length += GetDistance(from, to) + GetDistance(to, from);   
            geo_length += geo::ComputeDistance(from->coordinates, to->coordinates) * 2;
        }
    }   
   
    bus_stat.unique_stops_count = UniqueStopsCount(bus_number);   
    bus_stat.route_length = route_length;
    bus_stat.curvature = route_length / geo_length;   
   
    return bus_stat;   
}
   
size_t Catalogue::UniqueStopsCount(std::string_view bus_number) const {   
    std::unordered_set<std::string_view> unique_stops;   
    const auto& bus = *busname_to_bus_.at(bus_number); 
    for (const auto& stop : bus.stops) {   
        unique_stops.insert(stop->name);   
    }   
    return unique_stops.size();   
}   
   
const std::unordered_set<std::string>& Catalogue::GetBusesByStop(std::string_view stop_name) const {
    auto stop_iter = stopname_to_stop_.find(stop_name);
    if (stop_iter != stopname_to_stop_.end()) {
        return stop_iter->second->buses_by_stop;
    }
    static const std::unordered_set<std::string> empty;
    return empty;
}
   
void Catalogue::SetDistance(const Stop* from, const Stop* to, const int distance) {   
    stop_distances_[{from, to}] = distance;   
}   
   
int Catalogue::GetDistance(const Stop* from, const Stop* to) const {   
    auto it = stop_distances_.find({from, to});  
    if (it != stop_distances_.end()) return it->second;  
      
    it = stop_distances_.find({to, from});  
    if (it != stop_distances_.end()) return it->second;  
      
    return 0;   
}   

const std::deque<Bus>& Catalogue::GetAllBuses() const {
    return all_buses_;
}

const std::deque<Stop>& Catalogue::GetAllStops() const {
    return all_stops_;
}

}