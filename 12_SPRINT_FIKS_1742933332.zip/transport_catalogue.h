#pragma once 
 
#include "geo.h" 
#include "domain.h" 
 
#include <iostream> 
#include <deque> 
#include <string> 
#include <unordered_map> 
#include <vector> 
#include <stdexcept> 
#include <optional> 
#include <unordered_set> 
#include <set> 
#include <map> 
 
namespace transport { 
 
struct StopDistancesHasher { 
    size_t operator()(const std::pair<const Stop*, const Stop*>& points) const { 
        size_t h1 = std::hash<const void*>{}(points.first); 
        size_t h2 = std::hash<const void*>{}(points.second); 
        return h1 ^ (h2 << 1); 
    } 
}; 
 
class Catalogue { 
public: 
    void AddStop(const Stop& stop);
    void AddRoute(const Bus& bus);
    const Bus* FindRoute(std::string_view bus_number) const; 
    const Stop* FindStop(std::string_view stop_name) const; 
    std::optional<BusStat> GetBusStat(std::string_view bus_number) const; 
    const std::unordered_set<std::string>& GetBusesByStop(std::string_view stop_name) const;
    void SetDistance(const Stop* from, const Stop* to, int distance); 
    int GetDistance(const Stop* from, const Stop* to) const; 
    const std::deque<Bus>& GetAllBuses() const;
    const std::deque<Stop>& GetAllStops() const;
 
private: 
    size_t UniqueStopsCount(std::string_view bus_number) const; 
 
    std::deque<Bus> all_buses_; 
    std::deque<Stop> all_stops_; 
    std::unordered_map<std::string_view, const Bus*> busname_to_bus_; 
    std::unordered_map<std::string_view, Stop*> stopname_to_stop_; 
    std::unordered_map<std::pair<const Stop*, const Stop*>, int, StopDistancesHasher> stop_distances_; 
 
    std::unordered_map<const Stop*, std::unordered_set<const Bus*>> stop_to_buses_; 
}; 
 
}