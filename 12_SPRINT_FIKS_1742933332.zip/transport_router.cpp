#include "transport_router.h"

namespace transport {

TransportRouter::TransportRouter(const Catalogue& catalogue, const RoutingSettings& settings)
    : catalogue_(catalogue)
    , settings_(settings) {
    BuildGraph();
}

void TransportRouter::AddEdge(
    graph::VertexId from_vertex,
    graph::VertexId to_vertex,
    std::string_view bus_name,
    int span_count,
    double route_distance
) {
    // Переводим скорость из км/ч в м/с:
    double velocity_mps = settings_.bus_velocity * 1000.0 / 3600.0;
    double time = route_distance / velocity_mps; // время в секундах
    
    // Добавляем ребро
    graph_->AddEdge({
        from_vertex,
        to_vertex,
        time
    });
    
    // Сохраняем информацию о ребре
    edge_info_.push_back({BusItem{
        std::string(bus_name),
        span_count,
        time / 60.0  // время в минутах
    }});
}

void TransportRouter::BuildGraph() {
    // Create a map from the deque of stops for compatibility with the existing code
    std::map<std::string_view, const Stop*> stops;
    for (const auto& stop : catalogue_.GetAllStops()) {
        stops[stop.name] = &stop;
    }
    
    // Создаем по две вершины для каждой остановки: для ожидания и для посадки
    size_t vertex_count = stops.size() * 2;
    graph_ = std::make_unique<graph::DirectedWeightedGraph<double>>(vertex_count);
    
    size_t vertex_id = 0;
    for (const auto& [stop_name, stop_ptr] : stops) {
        stop_to_vertices_[stop_name] = {vertex_id, vertex_id + 1};
        
        // Добавляем ребро ожидания между вершинами "ожидание" и "посадка"
        double wait_time = settings_.bus_wait_time * 60.0; // в секундах
        graph_->AddEdge({
            vertex_id,     // от вершины ожидания
            vertex_id + 1, // к вершине посадки
            wait_time      // время ожидания в секундах
        });
        
        // Сохраняем информацию о ребре
        edge_info_.push_back(EdgeInfo{WaitItem{std::string(stop_name), static_cast<double>(settings_.bus_wait_time)}});
        
        vertex_id += 2;
    }
    
    // Добавляем ребра поездок на автобусах
    std::map<std::string_view, const Bus*> buses;
    for (const auto& bus : catalogue_.GetAllBuses()) {
        buses[bus.number] = &bus;
    }
    
    for (const auto& [bus_name, bus_ptr] : buses) {
    if (bus_ptr->stops.empty()) continue;
    
        for (size_t i = 0; i < bus_ptr->stops.size() - 1; ++i) {
            const Stop* from = bus_ptr->stops[i];
            
            // Индекс вершины посадки
            graph::VertexId from_vertex = stop_to_vertices_[from->name].bus_vertex;
            
            double route_distance = 0.0;
            for (size_t j = i + 1; j < bus_ptr->stops.size(); ++j) {
                const Stop* to = bus_ptr->stops[j];
                
                // Добавляем расстояние между остановками
                route_distance += catalogue_.GetDistance(bus_ptr->stops[j-1], to);
                
                // Индекс вершины ожидания на остановке прибытия
                graph::VertexId to_vertex = stop_to_vertices_[to->name].wait_vertex;

                // Создаем ребро и сохраняем информацию о нем
                AddEdge(from_vertex, to_vertex, bus_name, static_cast<int>(j - i), route_distance);
            }
        }
        
        // Для некольцевых маршрутов добавляем обратный путь
        if (!bus_ptr->is_circular && bus_ptr->stops.size() > 1) {
            for (size_t i = bus_ptr->stops.size() - 1; i > 0; --i) {
                const Stop* from = bus_ptr->stops[i];
                graph::VertexId from_vertex = stop_to_vertices_[from->name].bus_vertex;
                
                double route_distance = 0.0;
                for (size_t j = i - 1; j != size_t(-1); --j) {
                    const Stop* to = bus_ptr->stops[j];
                    route_distance += catalogue_.GetDistance(bus_ptr->stops[j+1], to);
                    
                    graph::VertexId to_vertex = stop_to_vertices_[to->name].wait_vertex;
                    
                    // Создаем ребро и сохраняем информацию о нем
                    AddEdge(from_vertex, to_vertex, bus_name, static_cast<int>(i - j), route_distance);
                    
                    if (j == 0) break;
                }
            }
        }
    }
    
    // Создаем маршрутизатор на основе графа
    router_ = std::make_unique<graph::Router<double>>(*graph_);
}

std::optional<TransportRouter::RouteInfo> TransportRouter::BuildRoute(
    std::string_view from, std::string_view to) const {
    
    // Если начальная и конечная остановки совпадают, возвращаем пустой маршрут с нулевым временем
    if (from == to) {
        return RouteInfo{0.0, {}};
    }
    
    // Находим вершины для остановок
    auto it_from = stop_to_vertices_.find(from);
    auto it_to = stop_to_vertices_.find(to);
    
    if (it_from == stop_to_vertices_.end() || it_to == stop_to_vertices_.end()) {
        return std::nullopt;
    }
    
    // Строим маршрут
    auto route = router_->BuildRoute(
        it_from->second.wait_vertex,
        it_to->second.wait_vertex
    );
    
    if (!route) {
        return std::nullopt;
    }
    
    // Формируем результат
    RouteInfo result;
    result.total_time = route->weight / 60.0;
    
    for (const auto& edge_id : route->edges) {
        result.items.push_back(edge_info_[edge_id].item);
    }
    
    return result;
}

} // namespace transport