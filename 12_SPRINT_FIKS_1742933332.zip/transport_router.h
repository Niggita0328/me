#pragma once

#include "transport_catalogue.h"
#include "domain.h"
#include "graph.h"
#include "router.h"

#include <memory>
#include <vector>
#include <unordered_map>
#include <string_view>
#include <variant>
#include <optional>

namespace transport {

class TransportRouter {
public:
    TransportRouter(const Catalogue& catalogue, const RoutingSettings& settings);

    struct WaitItem {
        std::string stop_name;
        double time = 0.0;
    };

    struct BusItem {
        std::string bus;
        int span_count = 0;
        double time = 0.0;
    };

    using RouteItem = std::variant<WaitItem, BusItem>;

    struct RouteInfo {
        double total_time = 0.0;
        std::vector<RouteItem> items;
    };

    std::optional<RouteInfo> BuildRoute(std::string_view from, std::string_view to) const;

private:
    struct VertexIds {
        graph::VertexId wait_vertex;
        graph::VertexId bus_vertex;
    };

    struct EdgeInfo {
        RouteItem item;
    };

    void AddEdge(
        graph::VertexId from_vertex,
        graph::VertexId to_vertex,
        std::string_view bus_name,
        int span_count,
        double route_distance
    );

    void BuildGraph();
    
    const Catalogue& catalogue_;
    const RoutingSettings& settings_;
    
    std::unordered_map<std::string_view, VertexIds> stop_to_vertices_;
    std::unique_ptr<graph::DirectedWeightedGraph<double>> graph_;
    std::unique_ptr<graph::Router<double>> router_;
    
    std::vector<EdgeInfo> edge_info_;
};

} // namespace transport