#pragma once
#include <cassert>
#include <cstdlib>
#include <new>
#include <utility>
#include <memory>
#include <type_traits>
#include <algorithm>

template <typename T>
class RawMemory {
public:
    RawMemory() = default;
    explicit RawMemory(size_t capacity)
        : buffer_(Allocate(capacity))
        , capacity_(capacity) {
    }
    ~RawMemory() {
        Deallocate(buffer_);
    }
    
    // Запрещаем копирование
    RawMemory(const RawMemory&) = delete;
    RawMemory& operator=(const RawMemory&) = delete;
    
    // Добавляем перемещение
    RawMemory(RawMemory&& other) noexcept 
        : buffer_(std::exchange(other.buffer_, nullptr))
        , capacity_(std::exchange(other.capacity_, 0)) {
    }
    RawMemory& operator=(RawMemory&& rhs) noexcept {
        if (this != &rhs) {
            Deallocate(buffer_);
            buffer_ = std::exchange(rhs.buffer_, nullptr);
            capacity_ = std::exchange(rhs.capacity_, 0);
        }
        return *this;
    }

    T* operator+(size_t offset) noexcept {
        assert(offset <= capacity_);
        return buffer_ + offset;
    }
    const T* operator+(size_t offset) const noexcept {
        return const_cast<RawMemory&>(*this) + offset;
    }
    const T& operator[](size_t index) const noexcept {
        return const_cast<RawMemory&>(*this)[index];
    }
    T& operator[](size_t index) noexcept {
        assert(index < capacity_);
        return buffer_[index];
    }
    void Swap(RawMemory& other) noexcept {
        std::swap(buffer_, other.buffer_);
        std::swap(capacity_, other.capacity_);
    }
    const T* GetAddress() const noexcept {
        return buffer_;
    }
    T* GetAddress() noexcept {
        return buffer_;
    }
    size_t Capacity() const {
        return capacity_;
    }
private:
    // Выделяет сырую память под n элементов и возвращает указатель на неё
    static T* Allocate(size_t n) {
        return n != 0 ? static_cast<T*>(operator new(n * sizeof(T))) : nullptr;
    }
    // Освобождает сырую память, выделенную ранее по адресу buf при помощи Allocate
    static void Deallocate(T* buf) noexcept {
        operator delete(buf);
    }
    T* buffer_ = nullptr;
    size_t capacity_ = 0;
};

template <typename T>
class Vector {
public:
    using iterator = T*;
    using const_iterator = const T*;
    
    iterator begin() noexcept {
        return data_.GetAddress();
    }

    iterator end() noexcept {
        return data_.GetAddress() + size_;
    }

    const_iterator begin() const noexcept {
        return data_.GetAddress();
    }

    const_iterator end() const noexcept {
        return data_.GetAddress() + size_;
    }

    const_iterator cbegin() const noexcept {
        return data_.GetAddress();
    }

    const_iterator cend() const noexcept {
        return data_.GetAddress() + size_;
    }
    
    Vector() = default;

    explicit Vector(size_t size)
        : data_(size)
        , size_(size)  //
    {
        std::uninitialized_value_construct_n(data_.GetAddress(), size);
    }

    Vector(const Vector& other)
        : data_(other.size_)
        , size_(other.size_)  //
    {
        std::uninitialized_copy_n(other.data_.GetAddress(), other.size_, data_.GetAddress());
    }
    
    // Перемещающий конструктор
    Vector(Vector&& other) noexcept
        : data_(std::move(other.data_))
        , size_(std::exchange(other.size_, 0)) {
    }

    ~Vector() {
        std::destroy_n(data_.GetAddress(), size_);
    }
    
    // Оператор копирующего присваивания
    Vector& operator=(const Vector& rhs) {
        if (this != &rhs) {
            if (rhs.size_ > data_.Capacity()) {
                // Если не хватает места - используем copy-and-swap
                Vector rhs_copy(rhs);
                Swap(rhs_copy);
            } else {
                // Копируем в существующие элементы
                std::copy_n(rhs.data_.GetAddress(), std::min(size_, rhs.size_), data_.GetAddress());
                
                if (size_ < rhs.size_) {
                    // Если у rhs больше элементов, то создаем новые элементы
                    std::uninitialized_copy_n(rhs.data_.GetAddress() + size_, rhs.size_ - size_, data_.GetAddress() + size_);
                } else if (size_ > rhs.size_) {
                    // Если у rhs меньше элементов, то удаляем лишние элементы
                    std::destroy_n(data_.GetAddress() + rhs.size_, size_ - rhs.size_);
                }
                size_ = rhs.size_;
            }
        }
        return *this;
    }
    
    // Оператор перемещающего присваивания
    Vector& operator=(Vector&& rhs) noexcept {
        if (this != &rhs) {
            Swap(rhs);
        }
        return *this;
    }

    void Reserve(size_t new_capacity) {
        if (new_capacity <= data_.Capacity()) {
            return;
        }
        
        RawMemory<T> new_data(new_capacity);
        MoveOrCopyElements(data_.GetAddress(), size_, new_data.GetAddress());
        std::destroy_n(data_.GetAddress(), size_);
        data_.Swap(new_data);
    }
    
    void Resize(size_t new_size) {
        if (new_size < size_) {
            std::destroy_n(data_.GetAddress() + new_size, size_ - new_size);
        } else if (new_size > size_) {
            Reserve(new_size);
            std::uninitialized_value_construct_n(data_.GetAddress() + size_, new_size - size_);
        }
        size_ = new_size;
    }
    
    void PushBack(const T& value) {
        EmplaceBack(value);
    }
    
    void PushBack(T&& value) {
        EmplaceBack(std::move(value));
    }
    
    void PopBack() noexcept {
        assert(size_ > 0);
        std::destroy_at(data_.GetAddress() + size_ - 1);
        --size_;
    }
    
    void Swap(Vector& other) noexcept {
        data_.Swap(other.data_);
        std::swap(size_, other.size_);
    }

    size_t Size() const noexcept {
        return size_;
    }

    size_t Capacity() const noexcept {
        return data_.Capacity();
    }

    const T& operator[](size_t index) const noexcept {
        return const_cast<Vector&>(*this)[index];
    }

    T& operator[](size_t index) noexcept {
        assert(index < size_);
        return data_[index];
    }

    template <typename... Args>
    T& EmplaceBack(Args&&... args) {
        return *Emplace(end(), std::forward<Args>(args)...);
    }

    template <typename... Args>
    iterator Emplace(const_iterator pos, Args&&... args) {
        size_t pos_idx = pos - cbegin();
        assert(pos_idx <= size_);
        
        if (size_ == Capacity()) {
            return EmplaceWithReallocation(pos_idx, std::forward<Args>(args)...);
        } else {
            return EmplaceWithoutReallocation(pos_idx, std::forward<Args>(args)...);
        }
    }

    iterator Insert(const_iterator pos, const T& value) {
        return Emplace(pos, value);
    }

    iterator Insert(const_iterator pos, T&& value) {
        return Emplace(pos, std::move(value));
    }

    iterator Erase(const_iterator pos) {
        assert(pos >= begin() && pos < end());
        
        size_t pos_idx = pos - cbegin();
        iterator pos_it = begin() + pos_idx;
        
        if (pos_idx < size_ - 1) {
            std::move(pos_it + 1, end(), pos_it);
        }
        
        std::destroy_at(data_.GetAddress() + size_ - 1);
        --size_;
        
        return pos_it;
    }

private:
    // Вспомогательный метод для перемещения или копирования элементов
    void MoveOrCopyElements(const T* from, size_t count, T* to) {
        if constexpr (std::is_nothrow_move_constructible_v<T> || !std::is_copy_constructible_v<T>) {
            std::uninitialized_move_n(from, count, to);
        } else {
            std::uninitialized_copy_n(from, count, to);
        }
    }

    // Вспомогательный метод для вставки с реаллокацией памяти
    template <typename... Args>
    iterator EmplaceWithReallocation(size_t pos_idx, Args&&... args) {
        size_t new_capacity = size_ == 0 ? 1 : size_ * 2;
        RawMemory<T> new_data(new_capacity);
        
        new (new_data + pos_idx) T(std::forward<Args>(args)...);
        
        try {
            MoveOrCopyElements(data_.GetAddress(), pos_idx, new_data.GetAddress());
        } catch (...) {
            std::destroy_at(new_data + pos_idx);
            throw;
        }
        
        try {
            MoveOrCopyElements(data_.GetAddress() + pos_idx, size_ - pos_idx, new_data.GetAddress() + pos_idx + 1);
        } catch (...) {
            std::destroy_n(new_data.GetAddress(), pos_idx + 1);
            throw;
        }
        
        std::destroy_n(data_.GetAddress(), size_);
        data_.Swap(new_data);
        ++size_;
        return begin() + pos_idx;
    }

    // Вспомогательный метод для вставки без реаллокации памяти
    template <typename... Args>
    iterator EmplaceWithoutReallocation(size_t pos_idx, Args&&... args) {
        if (pos_idx < size_) {
            // Создаем копию вставляемого элемента
            T temp_obj(std::forward<Args>(args)...);
            
            // Перемещаем последний элемент в неинициализированную память
            new (data_ + size_) T(std::move(data_[size_ - 1]));
            
            // Перемещаем элементы с конца до позиции вставки
            for (size_t i = size_ - 1; i > pos_idx; --i) {
                data_[i] = std::move(data_[i - 1]);
            }
            
            // Вставляем элемент
            data_[pos_idx] = std::move(temp_obj);
        } else {
            new (data_ + pos_idx) T(std::forward<Args>(args)...);
        }
        ++size_;
        return begin() + pos_idx;
    }

    RawMemory<T> data_;
    size_t size_ = 0;
};